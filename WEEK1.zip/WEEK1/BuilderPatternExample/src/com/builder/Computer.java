package com.builder;

public class Computer {
	private final String CPU;
    private final String RAM;
    private final String Storage;
    private final boolean isGraphicsCardIncluded;
    private final boolean isBluetoothIncluded;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.Storage = builder.Storage;
        this.isGraphicsCardIncluded = builder.isGraphicsCardIncluded;
        this.isBluetoothIncluded = builder.isBluetoothIncluded;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", Storage=" + Storage +
                ", GraphicsCardIncluded=" + isGraphicsCardIncluded + 
                ", BluetoothIncluded=" + isBluetoothIncluded + "]";
    }

    // Static nested Builder class
    public static class Builder {
        private final String CPU;
        private final String RAM;
        private final String Storage;
        private boolean isGraphicsCardIncluded = false;
        private boolean isBluetoothIncluded = false;

        public Builder(String CPU, String RAM, String Storage) {
            this.CPU = CPU;
            this.RAM = RAM;
            this.Storage = Storage;
        }

        public Builder setGraphicsCardIncluded(boolean isGraphicsCardIncluded) {
            this.isGraphicsCardIncluded = isGraphicsCardIncluded;
            return this;
        }

        public Builder setBluetoothIncluded(boolean isBluetoothIncluded) {
            this.isBluetoothIncluded = isBluetoothIncluded;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
