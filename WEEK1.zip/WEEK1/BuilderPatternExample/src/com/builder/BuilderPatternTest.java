package com.builder;

public class BuilderPatternTest {

	public static void main(String[] args) {
		Computer gamingPC = new Computer.Builder("Intel i9", "16GB", "1TB SSD")
                .setGraphicsCardIncluded(true)
                .setBluetoothIncluded(true)
                .build();
		Computer officePC = new Computer.Builder("Intel i5", "8GB", "500GB HDD")
              .build();
		System.out.println(gamingPC);
		System.out.println(officePC);
		}
}
