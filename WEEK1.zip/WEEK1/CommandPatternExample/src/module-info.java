/**
 * 
 */
/**
 * @author dell
 *
 */
module CommandPatternExample {
}