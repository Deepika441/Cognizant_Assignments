package com.Command;

public interface Command {
	void execute();

}
