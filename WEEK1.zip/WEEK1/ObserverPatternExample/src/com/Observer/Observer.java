package com.Observer;

public interface Observer {
	void update(String stockName, double stockPrice);
}
