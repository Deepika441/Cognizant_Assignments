/**
 * 
 */
/**
 * @author dell
 *
 */
module ObserverPatternExample {
}