/**
 * 
 */
/**
 * @author dell
 *
 */
module DependencyInjectionExample {
}