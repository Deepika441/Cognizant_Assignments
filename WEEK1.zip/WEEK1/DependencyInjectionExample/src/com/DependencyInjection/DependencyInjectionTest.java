package com.DependencyInjection;

public class DependencyInjectionTest {

	public static void main(String[] args) {
		 CustomerRepository customerRepository = new CustomerRepositoryImpl();
	        CustomerService customerService = new CustomerService(customerRepository);
	        String customerInfo = customerService.getCustomerInfo(1);
	        System.out.println(customerInfo);
	    }

}
