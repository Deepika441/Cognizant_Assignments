package com.DependencyInjection;

public interface CustomerRepository {
	String findCustomerById(int id);
}
