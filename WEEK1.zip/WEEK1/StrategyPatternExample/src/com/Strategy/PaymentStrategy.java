package com.Strategy;

public interface PaymentStrategy {
	void pay(double amount);

}
