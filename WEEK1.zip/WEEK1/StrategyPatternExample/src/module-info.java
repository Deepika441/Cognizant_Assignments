/**
 * 
 */
/**
 * @author dell
 *
 */
module StrategyPatternExample {
}