package com.Management;

class Order {
 private String orderId;
 private String customerName;
 private double totalPrice;

 Order(String orderId, String customerName, double totalPrice) {
     this.orderId = orderId;
     this.customerName = customerName;
     this.totalPrice = totalPrice;
 }

 String getOrderId() {
     return orderId;
 }

 String getCustomerName() {
     return customerName;
 }

 double getTotalPrice() {
     return totalPrice;
 }

 @Override
 public String toString() {
     return "Order [orderId=" + orderId + ", customerName=" + customerName + ", totalPrice=" + totalPrice + "]";
 }
}
class BubbleSort {
 public static void bubbleSort(Order[] orders) {
     int n = orders.length;
     boolean swapped;
     for (int i = 0; i < n - 1; i++) {
         swapped = false;
         for (int j = 0; j < n - i - 1; j++) {
             if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                 Order temp = orders[j];
                 orders[j] = orders[j + 1];
                 orders[j + 1] = temp;
                 swapped = true;
             }
         }
         if (!swapped) break;
     }
 }
}
class QuickSort {
 public static void quickSort(Order[] orders, int low, int high) {
     if (low < high) {
         int pi = partition(orders, low, high);

         quickSort(orders, low, pi - 1);
         quickSort(orders, pi + 1, high);
     }
 }

 private static int partition(Order[] orders, int low, int high) {
     double pivot = orders[high].getTotalPrice();
     int i = (low - 1);

     for (int j = low; j < high; j++) {
         if (orders[j].getTotalPrice() <= pivot) {
             i++;
             Order temp = orders[i];
             orders[i] = orders[j];
             orders[j] = temp;
         }
     }
     Order temp = orders[i + 1];
     orders[i + 1] = orders[high];
     orders[high] = temp;

     return i + 1;
 }
}

public class SortingCustomerOrders {
 public static void main(String[] args) {
     Order[] orders = {
         new Order("O001", "Alice", 250.75),
         new Order("O002", "Bob", 175.50),
         new Order("O003", "Charlie", 320.00),
         new Order("O004", "Diana", 120.25),
         new Order("O005", "Eve", 290.00)
     };

     // Display original orders
     System.out.println("Original Orders:");
     displayOrders(orders);

     // Bubble Sort
     Order[] bubbleSortedOrders = orders.clone(); 
     BubbleSort.bubbleSort(bubbleSortedOrders);
     System.out.println("\nOrders Sorted by Bubble Sort:");
     displayOrders(bubbleSortedOrders);

     // Quick Sort
     Order[] quickSortedOrders = orders.clone(); 
     QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
     System.out.println("\nOrders Sorted by Quick Sort:");
     displayOrders(quickSortedOrders);
 }

 private static void displayOrders(Order[] orders) {
     for (Order order : orders) {
         System.out.println(order);
     }
 }
}



