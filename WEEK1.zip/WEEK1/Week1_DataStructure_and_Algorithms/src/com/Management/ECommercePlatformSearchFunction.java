package com.Management;

import java.util.Arrays;
import java.util.*;
class product1 {
    private String productId;
    private String productName;
    private String category;

    // Constructor
    public product1(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters
    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category + "]";
    }
}
class LinearSearch {
    public static product1 linearSearchById(product1[] products, String productId) {
        for (product1 product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    public static product1 linearSearchByName(product1[] products, String productName) {
        for (product1 product : products) {
            if (product.getProductName().equals(productName)) {
                return product;
            }
        }
        return null;
    }

    public static product1 linearSearchByCategory(product1[] products, String category) {
        for (product1 product : products) {
            if (product.getCategory().equals(category)) {
                return product;
            }
        }
        return null;
    }
}
class BinarySearch {
    public static product1 binarySearchById(product1[] products, String productId) {
        Arrays.sort(products, Comparator.comparing(product1::getProductId));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductId().compareTo(productId);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static product1 binarySearchByName(product1[] products, String productName) {
        Arrays.sort(products, Comparator.comparing(product1::getProductName));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareTo(productName);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static product1 binarySearchByCategory(product1[] products, String category) {
        Arrays.sort(products, Comparator.comparing(product1::getCategory));
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getCategory().compareTo(category);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
public class ECommercePlatformSearchFunction{
	public static void main(String[] args) {
    	product1[] products = {

            new product1("P001", "Smartphone", "Electronics"),
            new product1("P002", "Tablet", "Electronics"),
            new product1("P003", "Charger", "Accessories")
        };

        // Linear
        System.out.println("Linear Search by ID: " + LinearSearch.linearSearchById(products, "P001"));
        System.out.println("Linear Search by Name: " + LinearSearch.linearSearchByName(products, "Smartphone"));
        System.out.println("Linear Search by Category: " + LinearSearch.linearSearchByCategory(products, "Electronics"));

        // Binary
        System.out.println("Binary Search by ID: " + BinarySearch.binarySearchById(products, "P001"));
        System.out.println("Binary Search by Name: " + BinarySearch.binarySearchByName(products, "Smartphone"));
        System.out.println("Binary Search by Category: " + BinarySearch.binarySearchByCategory(products, "Electronics"));
    }
}



