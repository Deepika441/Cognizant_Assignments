package com.Management;

class Employee {
 private String employeeId;
 private String name;
 private String position;
 private double salary;

 Employee(String employeeId, String name, String position, double salary) {
     this.employeeId = employeeId;
     this.name = name;
     this.position = position;
     this.salary = salary;
 }

 String getEmployeeId() {
     return employeeId;
 }

 String getName() {
     return name;
 }

 String getPosition() {
     return position;
 }

 double getSalary() {
     return salary;
 }

 @Override
 public String toString() {
     return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary=" + salary + "]";
 }
}
public class EmployeeManagementSystem {
 private static Employee[] employees = new Employee[100]; 
 private static int size = 0; 
 public static void addEmployee(Employee employee) {
     if (size < employees.length) {
         employees[size++] = employee;
     } else {
         System.out.println("Array is full. Cannot add more employees.");
     }
 }
 public static Employee searchEmployeeById(String employeeId) {
     for (int i = 0; i < size; i++) {
         if (employees[i].getEmployeeId().equals(employeeId)) {
             return employees[i];
         }
     }
     return null;
 }
 public static void traverseEmployees() {
     if (size == 0) {
         System.out.println("No employees to display.");
     } else {
         for (int i = 0; i < size; i++) {
             System.out.println(employees[i]);
         }
     }
 }
 public static boolean deleteEmployeeById(String employeeId) {
     for (int i = 0; i < size; i++) {
         if (employees[i].getEmployeeId().equals(employeeId)) {
             for (int j = i; j < size - 1; j++) {
                 employees[j] = employees[j + 1];
             }
             employees[--size] = null; 
             return true;
         }
     }
     return false;
 }

 public static void main(String[] args) {
     addEmployee(new Employee("E001", "Rohini", "Developer", 70000));
     addEmployee(new Employee("E002", "Shriya", "Manager", 80000));
     addEmployee(new Employee("E003", "Charlie", "Analyst", 65000));
     System.out.println("All Employees:");
     traverseEmployees();
     System.out.println("\nSearching for Employee with ID E002:");
     Employee emp = searchEmployeeById("E002");
     if (emp != null) {
         System.out.println(emp);
     } else {
         System.out.println("Employee not found.");
     }
     System.out.println("\nDeleting Employee with ID E001:");
     boolean deleted = deleteEmployeeById("E001");
     if (deleted) {
         System.out.println("Employee deleted successfully.");
     } else {
         System.out.println("Employee not found.");
     }
     System.out.println("\nAll Employees After Deletion:");
     traverseEmployees();
 }
}

