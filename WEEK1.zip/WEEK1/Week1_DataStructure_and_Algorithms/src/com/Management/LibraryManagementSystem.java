package com.Management;

import java.util.Arrays;

class Book {
 private String bookId;
 private String title;
 private String author;
 Book(String bookId, String title, String author) {
     this.bookId = bookId;
     this.title = title;
     this.author = author;
 }
 String getBookId() {
     return bookId;
 }

 String getTitle() {
     return title;
 }

 String getAuthor() {
     return author;
 }

 @Override
 public String toString() {
     return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
 }
}

class LibraryManagementSystem {
 // Linear Search
 public static Book linearSearchByTitle(Book[] books, String title) {
     for (Book book : books) {
         if (book.getTitle().equalsIgnoreCase(title)) {
             return book;
         }
     }
     return null;
 }
 public static Book binarySearchByTitle(Book[] books, String title) {
     Arrays.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

     int left = 0;
     int right = books.length - 1;

     while (left <= right) {
         int mid = left + (right - left) / 2;
         int comparison = books[mid].getTitle().compareToIgnoreCase(title);

         if (comparison == 0) {
             return books[mid];
         } else if (comparison < 0) {
             left = mid + 1;
         } else {
             right = mid - 1;
         }
     }
     return null;
 }

 public static void main(String[] args) {
     Book[] books = {
         new Book("B001", "Java Programming", "John Doe"),
         new Book("B002", "Data Structures", "Jane Smith"),
         new Book("B003", "Algorithms", "Alice Brown"),
         new Book("B004", "Design Patterns", "Bob Johnson")
     };

     System.out.println("Linear Search for 'Data Structures':");
     Book bookLinear = linearSearchByTitle(books, "Data Structures");
     if (bookLinear != null) {
         System.out.println(bookLinear);
     } else {
         System.out.println("Book not found.");
     }

     System.out.println("\nBinary Search for 'Algorithms':");
     Book bookBinary = binarySearchByTitle(books, "Algorithms");
     if (bookBinary != null) {
         System.out.println(bookBinary);
     } else {
         System.out.println("Book not found.");
     }
 }
}

