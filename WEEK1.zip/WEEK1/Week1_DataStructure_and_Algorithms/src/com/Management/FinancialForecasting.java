package com.Management;


public class FinancialForecasting {

 public static double calculateFutureValue(double principal, double growthRate, int years) {
     if (years <= 0) {
         return principal;
     }
     
     return calculateFutureValue(principal * (1 + growthRate), growthRate, years - 1);
 }

 public static void main(String[] args) {
     double principal = 2000.0; // Initial investment
     double growthRate = 0.05;  // Growth rate (5%)
     int years = 10;            // Number of years to forecast

     double futureValue = calculateFutureValue(principal, growthRate, years);
     System.out.printf("Future value after %d years: %.2f%n", years, futureValue);
 }
}
