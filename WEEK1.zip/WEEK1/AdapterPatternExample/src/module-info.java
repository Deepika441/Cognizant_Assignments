/**
 * 
 */
/**
 * @author dell
 *
 */
module AdapterPatternExample {
}