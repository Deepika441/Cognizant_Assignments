package com.Adapter;

public interface PaymentProcessor {
	void processPayment(double amount);
}
