package com.Adapter;

public class SquareGateway {
	public void pay(double amount) {
        System.out.println("Processing payment of $" + amount + " via Square.");
    }
}
