/**
 * 
 */
/**
 * @author dell
 *
 */
module DecoratorPatternExample {
}