package com.Decorator;

public interface Notifier {
	void send(String message);
}
