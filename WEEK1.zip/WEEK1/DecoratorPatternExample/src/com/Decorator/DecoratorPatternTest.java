package com.Decorator;

public class DecoratorPatternTest {

	public static void main(String[] args) {
		 Notifier emailNotifier = new EmailNotifier();

	        // Wrap the email notifier with SMS and Slack decorators
	        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
	        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

	        // Send a notification using the decorated notifier
	        slackNotifier.send("Hello, this is a test notification.");
	}

}
