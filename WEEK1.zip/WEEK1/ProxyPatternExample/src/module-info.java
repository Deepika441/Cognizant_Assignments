/**
 * 
 */
/**
 * @author dell
 *
 */
module ProxyPatternExample {
}