package com.Proxy;

public class ProxyPatternTest {

	public static void main(String[] args) {
		Image image1 = new ProxyImage("image1.jpg");
        Image image2 = new ProxyImage("image2.jpg");

        // Image is loaded and displayed for the first time
        image1.display();

        // Image is cached and displayed immediately
        image1.display();

        // Image is loaded and displayed for the first time
        image2.display();

        // Image is cached and displayed immediately
        image2.display();

	}

}
