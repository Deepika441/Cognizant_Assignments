package com.Proxy;

public interface Image {
	void display();
}
