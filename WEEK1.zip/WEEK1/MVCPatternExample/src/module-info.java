/**
 * 
 */
/**
 * @author dell
 *
 */
module MVCPatternExample {
}