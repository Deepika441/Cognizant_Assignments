package com.librarymanagement.librarymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementAppApplication.class, args);
	}

}
